Stats Monitor widget (no launcher icon).

Build APK: Build > Build Bundle(s) / APK(s) > Build APK(s)
File: app/build/outputs/apk/debug/app-debug.apk
Then on the home screen: long press > Widgets > "Stats Monitor".
Tap the widget to force a refresh.
To show the Wi-Fi name: Settings > Apps > Stats Monitor > Permissions > Location > Allow.
