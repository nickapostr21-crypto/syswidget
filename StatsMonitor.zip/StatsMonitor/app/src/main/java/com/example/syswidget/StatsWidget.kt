package com.example.syswidget

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.view.View
import android.widget.RemoteViews
import java.io.File
import java.util.Locale

class StatsWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.example.syswidget.STATS_REFRESH"
        private const val FAST_MS = 3_000L    // screen on
        private const val SLOW_MS = 60_000L   // screen off
        private const val PREFS = "stats_prefs"
        private const val GB = 1_073_741_824.0

        private fun refreshIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, StatsWidget::class.java).setAction(ACTION_REFRESH)
            return PendingIntent.getBroadcast(
                ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun schedule(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val delay = if (pm.isInteractive) FAST_MS else SLOW_MS
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + delay,
                refreshIntent(ctx)
            )
        }

        private fun cancel(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(refreshIntent(ctx))
        }

        // Dots as decimal separator, same as the original screenshot
        private fun fmt(f: String, vararg a: Any) = String.format(Locale.US, f, *a)

        private fun uptime(): String {
            val s = SystemClock.elapsedRealtime() / 1000
            return fmt("Uptime: %dd %02d : %02d : %02d", s / 86400, (s % 86400) / 3600, (s % 3600) / 60, s % 60)
        }

        private fun batteryIntent(ctx: Context): Intent? =
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        // Highest current core frequency (the kernel may block this on some phones)
        private fun cpu(): String {
            var maxKhz = -1L
            for (i in 0 until 16) {
                if (!File("/sys/devices/system/cpu/cpu$i").exists()) break
                for (name in listOf("scaling_cur_freq", "cpuinfo_cur_freq")) {
                    try {
                        val v = File("/sys/devices/system/cpu/cpu$i/cpufreq/$name")
                            .readText().trim().toLong()
                        if (v > maxKhz) maxKhz = v
                        break
                    } catch (_: Exception) { }
                }
            }
            if (maxKhz <= 0) return "CPU: N/A"
            val mhz = maxKhz / 1000.0
            return if (mhz >= 1000) fmt("CPU: %.2f GHz", mhz / 1000) else fmt("CPU: %.0f MHz", mhz)
        }

        private fun storage(path: String): String {
            val st = StatFs(path)
            val total = st.blockCountLong * st.blockSizeLong
            val used = total - st.availableBlocksLong * st.blockSizeLong
            return fmt("%.2f/%.2f GB", used / GB, total / GB)
        }

        private fun ram(ctx: Context): String {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val usedMb = (mi.totalMem - mi.availMem) / 1_048_576
            val totalMb = mi.totalMem / 1_048_576
            return "Used Ram: $usedMb/${totalMb}MB"
        }

        // Wi-Fi name, or the mobile operator, or "No connection"
        @Suppress("DEPRECATION")
        private fun networkName(ctx: Context): String {
            try {
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "No connection"
                return when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                        val ssid = wm.connectionInfo?.ssid?.trim('"')
                        if (ssid.isNullOrEmpty() || ssid == "<unknown ssid>") "Wi-Fi" else ssid
                    }
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                        tm.networkOperatorName.ifEmpty { "Mobile data" }
                    }
                    else -> "Connected"
                }
            } catch (_: Exception) {
                return "--"
            }
        }

        // Returns (upload Mbps, download Mbps) since the previous refresh
        private fun network(ctx: Context): Pair<Double, Double> {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val now = SystemClock.elapsedRealtime()
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val lastT = sp.getLong("t", 0L)
            val lastRx = sp.getLong("rx", rx)
            val lastTx = sp.getLong("tx", tx)
            var up = 0.0
            var down = 0.0
            if (lastT > 0 && now > lastT && rx >= 0 && tx >= 0 && rx >= lastRx && tx >= lastTx) {
                val sec = (now - lastT) / 1000.0
                down = (rx - lastRx) * 8 / 1_000_000.0 / sec
                up = (tx - lastTx) * 8 / 1_000_000.0 / sec
            }
            sp.edit().putLong("t", now).putLong("rx", rx).putLong("tx", tx).apply()
            return Pair(up, down)
        }

        private fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_stats)

            v.setTextViewText(R.id.tv_uptime, uptime())

            val bi = batteryIntent(ctx)
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
            v.setTextViewText(R.id.tv_batt, if (level >= 0) "Battery Left: ${level * 100 / scale}%" else "Battery Left: --")
            v.setTextViewText(R.id.tv_temp, "Battery Temp: $temp °C")

            v.setTextViewText(R.id.tv_cpu, cpu())

            v.setTextViewText(R.id.tv_int, storage(Environment.getDataDirectory().path))

            // SD card: shown only if one is present
            val sd = ctx.getExternalFilesDirs(null).getOrNull(1)
            if (sd != null) {
                v.setViewVisibility(R.id.tv_ext_label, View.VISIBLE)
                v.setViewVisibility(R.id.tv_ext, View.VISIBLE)
                v.setTextViewText(R.id.tv_ext, try { storage(sd.path) } catch (_: Exception) { "--" })
            } else {
                v.setViewVisibility(R.id.tv_ext_label, View.GONE)
                v.setViewVisibility(R.id.tv_ext, View.GONE)
            }

            v.setTextViewText(R.id.tv_ram, ram(ctx))

            v.setTextViewText(R.id.tv_net, networkName(ctx))
            val (up, down) = network(ctx)
            v.setTextViewText(R.id.tv_up, fmt("Upload: %.2f Mbps", up))
            v.setTextViewText(R.id.tv_down, fmt("Download: %.2f Mbps", down))

            v.setOnClickPendingIntent(R.id.root, refreshIntent(ctx)) // tap = refresh
            mgr.updateAppWidget(ids, v)
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(ctx, mgr, ids)
        schedule(ctx)
    }

    override fun onEnabled(ctx: Context) = schedule(ctx)

    override fun onDisabled(ctx: Context) = cancel(ctx)

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, StatsWidget::class.java))
            if (ids.isNotEmpty()) {
                render(ctx, mgr, ids)
                schedule(ctx)
            }
        }
    }
}
