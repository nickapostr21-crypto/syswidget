package com.example.syswidget

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, UpdateService::class.java))
        setContentView(TextView(this).apply {
            text = "Η παρακολούθηση ξεκίνησε.\nΠρόσθεσε το widget \"Sys Widget\" στην αρχική οθόνη."
            textSize = 18f
            setPadding(48, 96, 48, 48)
        })
    }
}
