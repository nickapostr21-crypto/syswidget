package com.example.syswidget

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File

object SysStats {

    private fun readKhz(path: String): Int =
        try { File(path).readText().trim().toInt() } catch (e: Exception) { 0 }

    /** Highest current frequency across ALL cores (so the fast cores are counted). MHz, 0 if unreadable. */
    fun maxCpuMhz(): Int {
        var maxKhz = 0
        val n = Runtime.getRuntime().availableProcessors()
        for (i in 0 until n) {
            val v = readKhz("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
            if (v > maxKhz) maxKhz = v
        }
        if (maxKhz == 0) {
            File("/sys/devices/system/cpu/cpufreq").listFiles()?.forEach { policy ->
                val v = readKhz(File(policy, "scaling_cur_freq").path)
                if (v > maxKhz) maxKhz = v
            }
        }
        return maxKhz / 1000
    }

    private fun readNumber(path: String): Long =
        try { Regex("\\d+").find(File(path).readText())?.value?.toLong() ?: 0L }
        catch (e: Exception) { 0L }

    /** Current GPU frequency in MHz, or 0 if the system does not let apps read it. */
    fun gpuMhz(): Int {
        val paths = ArrayList<String>()
        File("/sys/class/devfreq").listFiles()?.forEach { d ->
            val n = d.name.lowercase()
            if (n.contains("mali") || n.contains("gpu")) paths.add(File(d, "cur_freq").path)
        }
        paths += listOf(
            "/sys/kernel/gpu/gpu_clock",
            "/sys/kernel/ged/hal/current_freqency",
            "/sys/module/ged/parameters/gpu_cur_freq",
            "/sys/class/misc/mali0/device/clock"
        )
        for (p in paths) {
            val v = readNumber(p)
            if (v <= 0) continue
            return when {
                v >= 10_000_000L -> (v / 1_000_000L).toInt() // Hz
                v >= 10_000L -> (v / 1000L).toInt()          // kHz
                else -> v.toInt()                            // MHz
            }
        }
        return 0
    }

    fun ramPercent(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt()
    }

    fun storagePercent(): Int {
        val s = StatFs(Environment.getDataDirectory().path)
        val total = s.totalBytes
        return (((total - s.availableBytes) * 100) / total).toInt()
    }
}
