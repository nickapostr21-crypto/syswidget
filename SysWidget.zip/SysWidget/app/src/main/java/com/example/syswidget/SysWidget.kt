package com.example.syswidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Locale

class SysWidget : AppWidgetProvider() {

    override fun onEnabled(context: Context) = startService(context)

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        startService(context)
        refresh(context)
    }

    companion object {
        fun startService(c: Context) {
            try {
                c.startForegroundService(Intent(c, UpdateService::class.java))
            } catch (e: Exception) {
                // Android may block this from the background; open the app once to start it.
            }
        }

        fun refresh(c: Context) {
            val v = RemoteViews(c.packageName, R.layout.widget)

            val mhz = SysStats.maxCpuMhz()
            v.setTextViewText(
                R.id.cpu_ghz,
                if (mhz > 0) String.format(Locale.US, "%.1f", mhz / 1000.0) else "--"
            )

            val gpu = SysStats.gpuMhz()
            v.setTextViewText(R.id.gpu_mhz, if (gpu > 0) "$gpu MHz" else "-- MHz")

            val ram = SysStats.ramPercent(c)
            v.setTextViewText(R.id.ram_text, "RAM $ram%")
            v.setProgressBar(R.id.ram_bar, 100, ram, false)

            val sto = SysStats.storagePercent()
            v.setTextViewText(R.id.sto_text, "Storage $sto%")
            v.setProgressBar(R.id.sto_bar, 100, sto, false)

            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.root, open)

            AppWidgetManager.getInstance(c)
                .updateAppWidget(ComponentName(c, SysWidget::class.java), v)
        }
    }
}
